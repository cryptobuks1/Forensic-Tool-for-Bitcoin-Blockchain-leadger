// This programm will read Output.txt file and will write values to table-details in database-Bitcoin
<?php

        require_once('../mysqli_connect.php');
	$file = fopen("Output.txt","r");
	
	// Setting Sno to start from 1	
        $query = "ALTER TABLE details AUTO_INCREMENT = 1";
	$response = mysqli_query($dbc,$query);

     
   while(!feof($file))
  	{

	$str =  fgets($file);
	//echo $str;
        $myarray = explode("+",$str);
	for($x=0;$x<count($myarray);$x++)
	 {
		
		$inside = explode("*",$myarray[$x]);
		$Name = $inside[1]; $Url=$inside[2]; $Addr = $inside[0]; $Inward=0; $Outward = 0; $dInward=0; $dOutward=0; $Bal=0;
	    if(strlen($Addr)>=30  && strlen($Addr)<=36)
		{
        	$query = "INSERT INTO details (Name, Url,Addr, Inward, dInward, Outward, dOutward,Bal) VALUES (?,?, ?, ?,?, ?, ?, ?)";       
        	$stmt = mysqli_prepare($dbc, $query);
       		mysqli_stmt_bind_param($stmt, "ssssssss",$Name, $Url,$Addr, $Inward, $dInward, $Outward,$dOutward, $Bal);
        	mysqli_stmt_execute($stmt);
		$Bal = $Bal + 1;
		}
	 }
	}
//	$query = "delete FROM details ORDER BY Sno DESC LIMIT 1";
//	$response = mysqli_query($dbc,$query);
	
	
	// removing /n from the end of the address
       // $query =update details SET Addr = TRIM(TRAILING '\n' FROM Addr);
       // $response = mysqli_query($dbc,$query);
	
	fclose($file);

?>

