<?php

$addr = 0;


$Var = system("sudo -u www-data python /var/www/html/app/fetchfromaddr.py ".$addr);

$arrayIO = explode("*",$Var);
$Inward = explode("+",$Var[0]);
$Outward explode("+",$Var[1]);


// If the query executed properly proceed
echo
'<html>

<title>     <link rel="stylesheet" href="style.css">  </title>

<body>

<div class="body" </div>
<div class="graph" align="center">
<table width="1400">
     <td>  <table border="2" width="400" bgcolor="#33ccff">
	      <tr> 
		<td width="250"><center> Address1-  </center></td>
		<td width="150"><center> Amount  </center></td>
	       </tr> 

              <tr>
                <td width="250"><center> hshj1-  </center></td>
                <td width="150"><center> 79799  </center></td>
               </tr>

	   </table>
     </td>

     <td> <table border="2" width="300" bgcolor="#33ccff">
              	<tr>
		  <td width="250"><center> Address2-   </center></td>
		</tr>
           </table>
     </td>


      <td>  <table border="2" width="400" bgcolor="#33ccff">
	      <tr>
                <td width="150"><center> Amount     <center></td> 
                <td><center width="250"> ADDress3-     <center></td>
	      </tr>
           </table>

      </td>
</table>
</div>

</body>
</html>';

?>
