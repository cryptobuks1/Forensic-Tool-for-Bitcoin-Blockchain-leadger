import sys

print "hiiii",sys.argv[1]
