# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 12:11:37 2017

@author: syed
"""
from smtplib import SMTP as SMTP 

# Given a blockno this Script can fetch all address in rest of the blocks;

import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0
addr = ""

# find address-> url+names just by block number
### Will generate a file containg bnameas and url of the address
count = 0
k = 0
t = 0

def Fetch(t,temp):
    blockno = str(t)
    url = "https://blockchain.info/block-height/"+blockno+"?format=json"
    response = urllib.urlopen(url)
    data = json.loads(response.read())
    val = ""
    for i in range(0,len(data['blocks'][0]['tx'])):
       # print i,count
        for j in range(0,len(data['blocks'][0]['tx'][i]['inputs'])):
            addr_tag = "addr"
            addr_tag_link = "addr_link"
            addr = ""
            if('prev_out' in data['blocks'][0]['tx'][i]['inputs'][j]):
                if('addr_tag' in data['blocks'][0]['tx'][i]['inputs'][j]['prev_out']):
                    if('addr_tag_link' in data['blocks'][0]['tx'][i]['inputs'][j]['prev_out']):                       
                        addr_tag = data['blocks'][0]['tx'][i]['inputs'][j]['prev_out']['addr_tag']
                        addr_tag_link = data['blocks'][0]['tx'][i]['inputs'][j]['prev_out']['addr_tag_link']
                        addr = data['blocks'][0]['tx'][i]['inputs'][j]['prev_out']['addr']
                        val =  addr_tag +"*"+ addr_tag_link+"*" + addr
                        flag = 0
                        for k in range(0,len(temp)):
                            flag = 0
                            if(temp[k] == val):
                              flag = 1
                              break
                        if(flag==0):
                            temp.append(val)
                    
                            
        for j in range(0,len(data['blocks'][0]['tx'][i]['out'])):
          #  print 'y'
            addr_tag = "addr"
            addr_tag_link = "addr_link"
            addr = ""
            if('prev_out' in data['blocks'][0]['tx'][i]['out'][j]):
                if('addr_tag' in data['blocks'][0]['tx'][i]['out'][j]):
                    if('addr_tag_link' in data['blocks'][0]['tx'][i]['out'][j]):                       
                        addr_tag = data['blocks'][0]['tx'][i]['out'][j]['addr_tag']
                        addr_tag_link = data['blocks'][0]['tx'][i]['out'][j]['addr_tag_link']
                        addr = data['blocks'][0]['tx'][i]['out'][j]['addr']
                        val =  addr_tag +"*"+ addr_tag_link+"*" + addr
                        flag = 0
                        for k in range(0,len(temp)):
                            flag = 0
                            if(temp[k] == val):
                              flag = 1
                              break
                        if(flag==0):
                            temp.append(val)
                                   
	
#checks in blockchain ledger for the latest block
def latest_block():      
    url = "https://blockchain.info/latestblock";
    response = urllib.urlopen(url)
    data = json.loads(response.read())
    return data["height"]
    

def test(t,temp):
    try:
        Fetch(t,temp)
    except:
        print "######################### Bad Block NO. Encounterd  #########################"
        t = t + 1
        test(t,temp)



u = sys.argv[1]
u = int(u)
#u = 471339
v = latest_block()
latestblock=str(v)+"*"+str(v)+"*"+str(v)
temp = ["Add+Add+Add",latestblock]

def Return():
	return addr

for t in range(u,v):
    test(t,temp)
 
for t in range(1,len(temp)):
   addr = addr + temp[t]
   if(t<len(temp)-1):
       addr = addr + "+"

print addr   
#Return()

   
