<?php

$Block=2;

$var = system("sudo -u www-data python /var/www/html/app/p.py ".$Block);

?>
