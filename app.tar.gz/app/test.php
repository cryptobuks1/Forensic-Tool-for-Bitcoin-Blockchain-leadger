<?php
 
    $addr = "13ThJTiHF3BvW6TTWtdN5nCEZrrNrnb9o4";
        // Running python script for each address
        $Var = system("sudo -u www-data python /var/www/html/app/fetchfromaddr.py ".$addr);
        $str = explode("+", $Var);
	$cnt = 0;
//	echo "******",$str[0],$str[1],$str[2],"********";

	$isvalid = $bitcoin->validateaddress($addr);
	if($isvalid['isvalid']) {
		//Address valid
		echo "Invalid Addrtess";
		}
	else echo "VAlid";
?>

