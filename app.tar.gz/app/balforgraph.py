# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 12:11:37 2017

@author: syed
"""


#   NOT USING   --> use other python file name+urlbyBlock.py


import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0

# given a valid address as input return current balance

addr = sys.argv[1]


def Fetch(addr):
    final_balance=0
    url = "https://blockchain.info/rawaddr/"+addr
   # print url
    response = urllib.urlopen(url)
    data = json.loads(response.read())
    
    final_balance = data['final_balance']

   # print final_balance;    
    return final_balance    
        

print Fetch(addr)
