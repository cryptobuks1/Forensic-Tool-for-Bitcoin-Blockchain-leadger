<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

//$query = "Select * from details";
//$response = @mysqli_query($dbc, $query);
$addr =  $_GET['addr'];
//if($response){
echo
'<html>
<head>
        <title> </title>
         <link rel="stylesheet" href="style.css">

</head>
<body>

                <div class="body"></div>
                <div class="header" > <center>IITB Internship</center>
		</div>

                <div  width="100%">
                        <table table-layout="fixed" width="1500" border="5" bgcolor="green">
                                                <tr>
                                                <th width="250"> Incoming Address</th>
                                                <th width="150"> Amount</th>
                                                <th width="225"> $$$$$$$$$$$$</th>
                                                <th width="250"> Mid Address</th>
                                                <th width="225"> $$$$$$$$$$$$ </th>
                                                <th width="150"> Amount </th>
                                                <th width="250"> Outward Adddress </th>
                                                </tr>
                        </table>
                </div>

          <div class="graph"> 
		<table width="1400" left="40">




		     <td>  <table  border="2" width="400" bgcolor="#33ccff" float="left"><br><br><br> ';
			ob_start();
			passthru('/usr/bin/python2.7 /var/www/html/app/addrforgraph.py '.$addr);
			$Var = ob_get_clean();

			$Array = explode("*",$Var);
			$Inward = explode("+",$Array[0]);
		        $Outward = explode("+",$Array[1]);
			$Inlength = count($Inward);
			$Outlength = count($Outward);
			$x = 0;
		    for($x =1;$x<$Inlength;$x++)
			{	
				$Ad = explode(":",$Inward[$x]);

				$query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
				$result = mysqli_query($dbc,$query);
				 if(mysqli_num_rows($result)>0)
				 {
							$row = $result->fetch_assoc();                                                
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
  					     echo'   <tr><td width="250" align="justify" bgcolor="#00ff00"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"><center> '.$Name.' </center></td>
                                             <td width="150"><center>'.$Ad[1].'</center></td>
                                             </tr>';
                                 }//if
				 else{	
              				echo'	<tr> 
				 	<td width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"><center> '.$Ad[0].'  </center></td>
                			 <td width="150"><center> '.$Ad[1].' </center></td>
           		       			</tr>';
				   }//else
		       }// Inward for looop
		       echo'   </table>
     		     </td>';


	echo'
		   <td>	
		  <table>';
		
		      $query = "select `Name`,`Url` from `details` where Addr='$addr'";
                                $result = mysqli_query($dbc,$query);
                         
		        if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                             echo'  <tr><td width="250" align="justify" bgcolor="#00ff00"> <a href="'.$Url.'" style="text-decoration:none"><center> '.$Name.'  </center></td>
                                                   </tr>';
                                 }//if
                                 else{
                                        echo'   <tr>
	                  			  <td width="250"><center> '.$addr.'</center></td>
		                               </tr>';
                                   }//else
		echo'  </table>
                    </td>';






	      	echo'		<td>  <table  border="2" width="400" bgcolor="#33ccff" float="left"> <br><br><br>';
			$x = 0;
		   for($x=1;$x<$Outlength;$x++)
			{       
				 $Ad = explode(":",$Outward[$x]);

				 $query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
                                 $result = mysqli_query($dbc,$query);
                                 if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                        echo' <tr>
                			   <td width="150"><center> '.$Ad[1].'<center></td>  
					   <td width="250" align="justify"  bgcolor="#00ff00"> <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"><center> '.$Name.' </center><td>
                                             </tr>';
                                 }//if
                                 else{
             				echo'	 <tr>
                			   <td width="150"><center> '.$Ad[1].' <center></td> 
                			   <td><center width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"><center> '.$Ad[0].'  </center></td>
              			  		</tr>';
				    }//else
			}//oUtward for loop  
          		echo'	 </table>

      			</td>';  
       echo'    </table>
                               
        </div>
</body>
</html>';
//} else {

//echo "Couldn't issue database query<br />";

//echo mysqli_error($dbc);

//}

// Close connection to the database
mysqli_close($dbc);

?>
