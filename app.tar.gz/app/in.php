<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

// Create a query for the database

// Get a response from the database by sending the connection
// and the query

$date = "2107-12-12 22:22:34";
$query = "SELECT `Time` FROM `refresh_history` ORDER BY `Till_Block` DESC LIMIT 1";
$response = @mysqli_query($dbc, $query);
$row = $response->fetch_assoc();
$date = $row['Time'];

$query = "SELECT * from details";
$response = @mysqli_query($dbc, $query);


// If the query executed properly proceed
if($response){
echo
'<html>
<head>
        <title>   </title>
	<link rel="stylesheet" href="st.css">
</head>
<body>


                <div  class="bar">  
		 <p> <abbr title="This page was last completly refreshed(crawled till newest block + balance was updated) till this date.">  Last Updated :: '.$date.' </abbr>  </p> 
		  <table>  <tr>   <abbr title="This button crawl blocks right from last updated Block to newest block. Also it will automatically update all fields corresponding to each address."> <form action="http://bitcoin.isrdc.iitb.ac.in/app/refresh.php">   <input type="submit" value="Refresh"> </form> </abbr> </tr>
						  <tr> <!-- <abbr title="Add new address to database max 1000 at a time. Start automatically from last crawled block." --> <form action="http://bitcoin.isrdc.iitb.ac.in/app/Add_addr.php">   <input type="submit" value=" Hunt for new Address"> </form></tr>
						  <tr> <!-- <abbr title="Update balance, in, Out, dIn, dout of all address present in local database." > --> <form action="http://bitcoin.isrdc.iitb.ac.in/app/ref_page.php">   <input type="submit" value="Update Balance"> </form>  </tr>
					     	  
				    </table>	

                        <table class="headtable">
                                                <tr>
                                                <th width="5%"><abbr title="Sno with which this addr is saved in local database"> S NO.</abbr></th>
                                                <th width="25%"><abbr title="This addr is attched to this name"> Name of merchant </abbr></th>
                                                <th width="25%"> <abbr title="Key addr">BTC Address </abbr></th>
                                                <th width="7%"><abbr title="Number of address which have paid to key address till now">In</abbr> </th>
                                                <th width="7%"><abbr title="Number of address which have paid till last refresh">dIn</abbr> </th>
                                                <th width="7%"><abbr title="Number of address which have received bitcoin from key address till now">Out </abbr> </th>
                                                <th width="7%"><abbr title="Number of address which have paid to key address till last refresh">dOut</abbr> </th>
                                                <th width="11%"> <abbr title="Number of BTC this address have till last refresh">Balance </title></th>
                                                </tr>
                        </table>
                </div>

          <div ><br> <br><br><br><br><br><br>
                        <table>';
           while($row = mysqli_fetch_array($response)){
							$b = (floatval($row['Bal']))*10**(-8);
							$Bal = number_format((float)$b, 8, '.', '');
               		                        echo' 
                                                <td width="5%" >'.$row['Sno'].'</td>
                                                <td width="25%" > <a href="'.$row['Url'].'>
								<div  style="height:100%;width:100%;text-decoration:none" style="height:100%;width:100%;text-decoration:none">'.$row['Name'].'</div></a></td>
                                                <td width="25%" > <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$row['Addr']."&in=".$row['Inward']."&out=".$row['Outward'].'" style="text-decoration:none">
								<div style="height:100%;width:100%">'
      								.$row['Addr'].'</div></a></td>
                                                <td width="7%" align="right">'.$row['Inward']. '</td>
                                                <td width="7%" align="right">'.$row['dInward']. '</td>
                                                <td width="7%" align="right">'.$row['Outward']. '</td>
                                                <td width="7%" align="right">'.$row['dOutward'].'</td>
                                                <td width="11%" align="right">'.$Bal.'</td>';
                                                echo'</tr>';
						}
                       echo' </table>
                               
                </div>
</body>
</html>';
} else {

echo "Couldn't issue database query<br />";

echo mysqli_error($dbc);

}

// Close connection to the database
mysqli_close($dbc);

?>
