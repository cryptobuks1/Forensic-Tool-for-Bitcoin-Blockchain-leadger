<?php
 
// Get a connection for the database
require_once('../mysqli_connect.php');

$Date = 0;
$Block = 0;        // Satoshi Block/ Parent Block
$record = 0;
$cnt = 0; // variable to count no. of record refreshed


// In,Out,dIn, dOut and balance
$sql = "SELECT * FROM details where Sno>3424";
$result = mysqli_query($dbc, $sql);
$count = 1;

echo ' <title>          </title>
        <body>  <a  class="Link" href="http://bitcoin.isrdc.iitb.ac.in/app/index.php" > <h1> Back to index.php </h1></a>';


if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) 
     {
        $inward = (int)$row['Inward'];
        $outward = (int)$row['Outward'];
        $addr = $row['Addr'];
        // Running python script for each address
        $Var = system("sudo -u www-data python /var/www/html/app/fetchfromaddr.py ".$addr);
        $str = explode("+", $Var);
	$cnt = 0;
	echo "******",$str[0],$str[1],$str[2],"********";
	if($cnt <= count($str)-1)
	{
	echo "IF",$str[0];
        $dinward=(int)$str[0] - $inward;
        $doutward = (int)$str[1] - $outward;
	$bal = $str[2];

	echo "$bal=                                          ",$bal;
	echo $dinward,$doutward;
        //update command
	if((int)$str[0] > 0)
	{	echo "yooooooooooooooooo";
        	$sql = "UPDATE details SET Inward='$str[0]',Outward='$str[1]',Bal='$bal',dInward='$dinward',dOutward='$doutward' WHERE Addr='$addr'";
		$res = mysqli_query($dbc,$sql);
		echo "----->>>>",$count,"<<<<------[[[",mysqli_affected_rows($dbc),"]]]";
		$count = $count + 1;
		 if(mysqli_affected_rows($dbc)>=0)
			{
			  echo "Updated";
			  $cnt = $cnt + 1;
			  echo $cnt;
			}//if
		else{
			echo "Error";
		    }//else


	}//if  
		$cnt = $cnt + 1;
	}//counting  if loop
    }//while
} else {
    echo "0 results";
}

echo ' <div> <h1> Updated balance of ' .$cnt. ' records in local database </h1> </body>'; 

mysqli_close($dbc);

//$conn->close()


?>

