<?php
 
// Get a connection for the database
require_once('../mysqli_connect.php');

$Date = 0;
$Block = 0;        // Satoshi Block/ Parent Block
$record = 0;

// finding the latest block
// Create a query for the database// finding latest line in mysql
$query = "SELECT * FROM refresh_history ORDER BY Till_Block DESC LIMIT 1";
$response = @mysqli_query($dbc, $query);
// If the query executed properly proceed


if($response){
		while($row = $response->fetch_assoc())
		{
			$Date = $row["Time"];  	
			$Block = $row["Till_Block"];
	//		$record = $row["Record_No"];
		}//while 
		echo "Block No:::",$Block,"\n";
	    }//if
       else {
		echo "Couldn't issue database query";
		echo mysqli_error($dbc);
	    }//else


//Runnnig script to fetch data using API API 
$var = system("sudo -u www-data python /var/www/html/app/refresh.py ".$Block);


$bigarray = explode("+",$var);

foreach ($bigarray as $key)
 { 
    echo gettype($key);
    $smallarray =explode("*", $key);
    $name = $smallarray[0];
    $url  = $smallarray[1]; 
    $addr = $smallarray[2];
	echo "\r\n","\r\n";
    if(strlen($addr)>=25 and strlen($addr)<=36)
    	{	echo "\r\n","New","\r\n",	

		$query = "SELECT `Addr` FROM `details` where Addr='$addr'";
		$response = mysqli_query($dbc, $query);
		if(mysqli_num_rows($response)>0){
						echo "--if--";
        				while($row = $response->fetch_assoc())
        					{
               		 				$Addr = $row["Addr"];
							echo $Addr,"[][][][][[]Matched","\r\n";
					
		        			}//while
        		    }//if
		       else {
      		  	         echo "else)))))))))))))))";
				 $a = 0;
 				 $query = "INSERT INTO details (Name, Url,Addr, Inward, dInward, Outward, dOutward,Bal) VALUES (?,?, ?, ?,?, ?, ?, ?)";
				 $stmt = mysqli_prepare($dbc, $query);
				 mysqli_stmt_bind_param($stmt, "ssssssss",$name, $url,$addr,$a, $a, $a,$a,$a);
				 mysqli_stmt_execute($stmt);
				 echo "yeah+++++++++++++++++Notmatched-Inserted";
                            }//else
		
		
        }//if 

}//loop



// In,Out,dIn, dOut and balance
$sql = "SELECT * FROM details";
$result = mysqli_query($dbc, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) 
     {
        $inward = (int)$row['Inward'];
        $outward = (int)$row['Outward'];
        $addr = $row['Addr'];
        // Running python script for each address
        $Var = system("sudo -u www-data python /var/www/html/app/fetchfromaddr.py ".$addr);
        $str = explode("+", $Var);
	$cnt = 0;
	//echo "******",$str[0],$str[1],$str[2],"********";
	if($cnt <= count($str)-1)
	{
	echo "IF",$str[0];
        $dinward=(int)$str[0] - $inward;
        $doutward = (int)$str[1] - $outward;
	$bal = $str[2];

	echo $dinward,$doutward;
        //update command
	if((int)$str[0] > 0)
	{	echo "yooooooooooooooooo";
        	$sql = "UPDATE details SET Inward='$str[0]',Outward='$str[1]',Bal='$bal',dInward='$dinward',dOutward='$doutward' WHERE Addr='$addr'";
		$res = mysqli_query($dbc,$sql);
		echo "[[[",mysqli_affected_rows($dbc),"]]]";
		 if(mysqli_affected_rows($dbc)>=0)
			{
			  echo "Updated";
			}//if
		else{
			echo "Error";
		    }//else


	}//if  
		$cnt = $cnt + 1;
	}//counting  if loop
    }//while
} else {
    echo "0 results";
}


mysqli_close($dbc);


//////////////////////////////////////////////------------------> update refresh_histry table in mysql
$smallarray = explode("+",$bigarray[0]);
$block = (int)$smallarray[0];

$servername = "localhost";
$username = "root";
$password = "pass";
$dbname = "Bitcoin";

$time = date('Y-m-d H:i:s');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$record = $record + 1;
$sql = "INSERT INTO refresh_history (Record_No,Time, Till_Block)VALUES ('$record','$time','$block');";

if ($conn->multi_query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close()


?>

