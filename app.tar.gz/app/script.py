import sys
print "hello World"+sys.argv[1]
