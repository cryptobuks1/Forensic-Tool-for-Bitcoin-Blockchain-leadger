# import libraries
import urllib2  
from bs4 import BeautifulSoup  

# specify the url


Str = ""
for i in range(0,71):    # as blockchain.info has only 71 pages for it. it can be changed
	x = i*50
	quote_page = 'https://blockchain.info/tags?filter=8&offset='+str(x)  
	print quote_page
	# query the website and return the html to the variable 'page'
	page = urllib2.urlopen(quote_page)  

	# parse the html using beautiful soap and store in variable `soup`
	soup = BeautifulSoup(page, 'html.parser')  

	# Take out the <div> of name and get its value
	table_box = soup.find("table",{"class": "table table-striped"})  

	table_body = table_box.find('tbody')

	rows = table_body.find_all('tr')

	data =[]

	for row in rows:
	    cols = row.find_all('td')
	    cols = [ele.text.strip() for ele in cols]
	    data.append([ele for ele in cols if ele]) # Get rid of empty values	
	    #for ele in cols:
	    #	print ele,

	for j in range(0,len(data)):
		Str = Str + data[j][0] +"*" + data[j][1] +"*" + data[j][2]
		if(j<len(data)):
			Str =Str + "+"

text_file = open("Output.txt", "w")
text_file.write(Str)
text_file.close()


print Str
