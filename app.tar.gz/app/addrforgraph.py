# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 12:11:37 2017

@author: syed
"""
from smtplib import SMTP as SMTP 

# Given a blockno this Script can fetch all address in rest of the blocks;

import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0
addr = ""

# find address-> url+names just by block number
### Will generate a file containg bnameas and url of the address


def Fetch(addr):
    i  = 0
    j = 0
    k = 0
    Str = "xyz"
    Str1= "abc"
    url = "https://blockchain.info/rawaddr/"+addr
    response = urllib.urlopen(url)
    data = json.loads(response.read())
    for i in range(0,len(data['txs'])):
	for j in range(0,len(data['txs'][i]['out'])):
           x =    data['txs'][i]['out'][j]['addr']
           y = str(data['txs'][i]['out'][j]['value'])
           z =    data['txs'][i]['hash']
	   p = x+":"+y+":"+z		
  	   Str = Str + "+" 
	   Str = Str  +  p
#           print x,y 
	

    for i in range(0,len(data['txs'])):
	for j in range(0,len(data['txs'][i]['inputs'])):
	   x = data['txs'][i]['inputs'][j]['prev_out']['addr']
	   y = str(data['txs'][i]['inputs'][j]['prev_out']['value'])
           z =    data['txs'][i]['hash']
	   p = x+ ":"+y+":"+z
           Str1 = Str1 + "+"
	   Str1 = Str1  + p
#	   print x,y    ################### 

    #print data['txs'][0]['hash']	
    print Str1+"*"+Str	
    return Str1+"*"+Str				                            






addr = sys.argv[1]
Fetch(addr)


