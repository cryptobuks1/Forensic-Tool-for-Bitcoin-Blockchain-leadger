<?php

$x = "0";
$y = floatval($x)*10**(-8);

echo  number_format((float)$y, 8, '.', '');

?>
