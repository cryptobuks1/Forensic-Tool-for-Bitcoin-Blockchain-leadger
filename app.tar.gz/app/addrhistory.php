<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

$addr =  $_GET['addr'];

$in = 0;
$out = 0;
$finalbal = 0; // input balance
$totalinbal = 0; // total inflow of BTC           
$totaloutbal = 0; // total outflow of BTC           
// If the query executed properly proceed

echo
'<html>
<head>
        <title> </title>
         <link rel="stylesheet" href="st.css">

</head>
<body>


                <div  class="bar" width="100%"> &emsp; &emsp; <!-- <table > <tr> <th> --><abbr title="Go back to filter page">  <form action="http://bitcoin.isrdc.iitb.ac.in/query/filter.php?addr='.$addr.'">    <input  type="submit" value="Query Page">  </form> </abbr> <!-- </tr></th></table> --> 
	<!--	<p class="add">  &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; <abbr title="Address which have paid to key addr">  #Inward_Transactions('.$in.') </abbr>    &emsp;&emsp; &emsp;&nbsp; &emsp;&emsp;  &emsp; &emsp; &emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; <abbr title="Key Addr"> '.$addr.' </abbr>   &emsp;  &emsp; &emsp;&emsp;  &emsp;&emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; &emsp; <abbr title="Address which have recieved bitcoin from key addr"> #Outward_Transactions('.$out.')  </abbr> </p> -->  <br><br><br><br>

                        <table class="headtable">
                                                <tr>
                                                <th width="290"> Incoming Address</th>
                                                <th width="125"> Amount</th>
                                                <th width="220"> Key Address</th>
                                                <th width="125"> Amount </th>
                                                <th width="290"> Outward Adddress </th>
                                                </tr>
                        </table>
                </div>
		<br><br><br><br><br><br><br>

          <div class="graph"> 

		<table class="maintable">




		     <td class="td2">  <table  width="400" bgcolor="#33ccff"  font-family="monospace" float="left"><br><br><br> ';
			ob_start();
			passthru('/usr/bin/python2.7 /var/www/html/app/addrforgraph.py '.$addr);
			$Var = ob_get_clean();

			$Array = explode("*",$Var);
			$Inward = explode("+",$Array[0]);
		        $Outward = explode("+",$Array[1]);
			$Inlength = count($Inward);
			$Outlength = count($Outward);
			$x = 0;
		    for($x =1;$x<$Inlength;$x++)
			{	
				$Ad = explode(":",$Inward[$x]);

						 $b = floatval($Ad[1])*10**(-8);
                                                 $Bal = number_format((float)$b, 8, '.', '');
						 $totalinbal = $totalinbal + $Bal;                // total recived no. of BTC irrespective of who has given
				$query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
				$result = mysqli_query($dbc,$query);
				if($addr != $Ad[0]) //stopping key address to get printed
				{
				//$inbal = $inbal + $Bal;
				$in = $in + 1;      // counter to display in summary
				 if(mysqli_num_rows($result)>0)
				 {
							$row = $result->fetch_assoc();                                                
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];

  					     echo'   <tr><td class="td3" width="250" align="justify" bgcolor="#00ff00"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"> '.$Name.'</td>
                                             <td class="td3" align="right" width="150">'.$Bal.'</td>
					     <td class="td3"  width="10"> <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0" alt="W3Schools"src="arrow.png" width="10" height="10"></a> </td>
                                             </tr>';
                                 }//if
				 else{	
              				echo'	<tr> 
				 	<td width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none">'.$Ad[0].'</td>
                			 <td width="150" align="right">'.$Bal.'</td>
					 <td  width="10" > <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0" alt="W3Schools"src="arrow.png" width="10" height="10"></a> </td>
           		       			</tr>';
				   }//else
				}// stopper for key address
			     else{
				  $finalbal = $finalbal - $Bal;
				}//subtracting the amount that key address has returned
		       }// Inward for looop
		       echo'   </table>
     		     </td>';


	echo'
		   <td class="td2">	
		  <table width="250" font-family="monospace" bgcolor="#33ccff" float="left">';
		
		      $query = "select `Name`,`Url` from `details` where Addr='$addr'";
                                $result = mysqli_query($dbc,$query);
		        if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                             echo'  <tr><td class="td3" width="250" align="justify" bgcolor="#00ff00"> <a href="'.$Url.'" style="text-decoration:none"><center> '.$Name.'  </center></td>
                                                   </tr>';
                                 }//if
                                 else{
                                        echo'   <tr >
	                  			  <td width="250"><center> '.$addr.'</center></td>
		                               </tr>';
                                   }//else
		echo'  </table>
                    </td>';






	      	echo'		<td class="td2">  <table  width="400" bgcolor="#33ccff" float="left"> ';
			$x = 0;
		   for($x=1;$x<$Outlength;$x++)
			{       
				 $Ad = explode(":",$Outward[$x]);
					
					$b = floatval($Ad[1])*10**(-8);
                                        $Bal = number_format((float)$b, 8, '.', '');

				 $totaloutbal = $totaloutbal + $Bal;
				 $query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
                                 $result = mysqli_query($dbc,$query);
			if($addr != $Ad[0])//Key address stopper
			{
				$out = $out + 1; // counting to print it in summary 
                                 if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                        echo' <tr>
					  <td class="td3"  width="10"> <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0" alt="W3Schools"src="arrow.png" width="10" height="10"></a> </td>
                			   <td class="td3" width="150" align="right">'.$Bal.'</td>  
					   <td class="td3" width="250" align="justify"  bgcolor="#00ff00"> <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none">'.$Name.'</td>
                                             </tr>';
                                 }//if
                                 else{
             				echo'	 <tr>
					   <td width="10"> <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0" alt="W3Schools"src="arrow.png"width="10" height="10"></a> </td>
                			   <td align="right" width="150">'.$Bal.'</td> 
                			   <td><width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"> '.$Ad[0].'</td>
              			  		</tr>';
				    }//else
			}//if key address stopper
			 else{
                                  $finalbal = $finalbal + $Bal;
                                }//subtracting the amount that key address has returned

			}//oUtward for loop  
          		echo'	 </table>

      			</td>';
	$fees = $totalinbal - $totaloutbal;
       echo' 	
	   </table>
                               
        </div>
	<div class="footer" width="100%"> <center> Page Summary </center> <br>
				 <table> <tr>	<th align="left"> #Inward Nodes('.$in.') Total #Received BTC('.$totalinbal.')  </th> </tr>
					 <tr>	<th> '.$addr.' :: Balance('.$finalbal.') BTC :: Fees('.$fees.') BTC </th> </tr>
				 	 <tr>	<th align="right"> #Outward Nodes('.$out.')   Total #Sent BTC('.$totaloutbal.') </th> </tr>
				</table>
	<br>
	</div>
</body>
</html>';

// Close connection to the database
mysqli_close($dbc);

?>
