# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 12:11:37 2017

@author: syed
"""


#   NOT USING   --> use other python file name+urlbyBlock.py


import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0

### input a id.txt file 1 address in each line
### Will generate a file containg bnameas and url of the address


addr = sys.argv[1]


count = 0
k = 0
t = 0

def Fetch(addr):
    n_in = 0    #no. of in transactions
    n_out = 0
    final_balance=0
    url = "https://blockchain.info/rawaddr/"+addr
    print url
    response = urllib.urlopen(url)
    data = json.loads(response.read())
    
    final_balance = data['final_balance']*(10**(-8))

    for i in range(0,len(data['txs'])):
        for j in range(0,len(data['txs'][i]['out'])):
            n_out = n_out + 1
      
        for j in range(0,len(data['txs'][i]['inputs'])):
                n_in = n_in + 1
                
    #print "n_out",n_out
    #print "n_in",n_in    
    #print "final_balance",final_balance        
    print str(n_in)+"+"+str(n_out)+"+"+str(final_balance)    
    return str(n_in)+"+"+str(n_out)+"+"+str(final_balance)    
        

print Fetch(addr)
