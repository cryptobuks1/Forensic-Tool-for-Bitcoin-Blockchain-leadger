# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 12:11:37 2017

@author: syed
"""
from smtplib import SMTP as SMTP 

# Given a blockno this Script can fetch all address in rest of the blocks;

import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0

# find address-> url+names just by block number
### Will generate a file containg bnameas and url of the address


def Fetch(addr):
    url = "https://blockchain.info/rawaddr/"+addr
    try:	
         response = urllib.urlopen(url)
   	 data = json.loads(response.read())
   	 i = 1
    except:
	 i = 0
    return i	 



addr = sys.argv[1]
k = Fetch(addr)

print k

