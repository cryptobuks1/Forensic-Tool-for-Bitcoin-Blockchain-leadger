<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

// Create a query for the database

// Get a response from the database by sending the connection
// and the query

$date = "2107-12-12 22:22:34";
$query = "SELECT `Time` FROM `refresh_history` ORDER BY `Till_Block` DESC LIMIT 1";
$response = @mysqli_query($dbc, $query);
$row = $response->fetch_assoc();
$date = $row['Time'];

$query = "SELECT * from details";
$response = @mysqli_query($dbc, $query);


// If the query executed properly proceed
if($response){
echo
'<html>
<head>
        <title>   </title>
	<link rel="stylesheet" href="st.css">
</head>
<body>


                <div  class="bar"> 
					<p> Last Updated :: '.$date.' &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a  class="Link" href="http://bitcoin.isrdc.iitb.ac.in/app/refresh.php" >Refresh</a>  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <a  class="Link" href="http://bitcoin.isrdc.iitb.ac.in/app/refresh.php" >Add Address</a> </p>
                        <table class="headtable">
                                                <tr>
                                                <th width="5%"> S NO.</th>
                                                <th width="25%"> Name of merchant</th>
                                                <th width="25%">  BTC Address</th>
                                                <th width="7%"> In </th>
                                                <th width="7%"> dIn </th>
                                                <th width="7%"> Out </th>
                                                <th width="7%"> dOut </th>
                                                <th width="11%">Balance</th>
                                                </tr>
                        </table>
                </div>

          <div ><br> <br><br><br><br><br><br>
                        <table>';
           while($row = mysqli_fetch_array($response)){
							$b = (floatval($row['Bal']))*10**(-8);
							$Bal = number_format((float)$b, 8, '.', '');
               		                        echo' 
                                                <td width="5%" >'.$row['Sno'].'</td>
                                                <td width="25%" > <a href="'.$row['Url'].'>
								<div  style="height:100%;width:100%;text-decoration:none" style="height:100%;width:100%;text-decoration:none">'.$row['Name'].'</div></a></td>
                                                <td width="25%" > <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$row['Addr']."&in=".$row['Inward']."&out=".$row['Outward'].'" style="text-decoration:none">
								<div style="height:100%;width:100%">'
      								.$row['Addr'].'</div></a></td>
                                                <td width="7%" align="right">'.$row['Inward']. '</td>
                                                <td width="7%" align="right">'.$row['dInward']. '</td>
                                                <td width="7%" align="right">'.$row['Outward']. '</td>
                                                <td width="7%" align="right">'.$row['dOutward'].'</td>
                                                <td width="11%" align="right">'.$Bal.'</td>';
                                                echo'</tr>';
						}
                       echo' </table>
                               
                </div>
</body>
</html>';
} else {

echo "Couldn't issue database query<br />";

echo mysqli_error($dbc);

}

// Close connection to the database
mysqli_close($dbc);

?>
