<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

// Create a query for the database
$query = "SELECT * from details";

// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);

// If the query executed properly proceed
if($response){
echo
'<html>
<head>
        <title> </title>
         <link rel="stylesheet" href="style.css">

</head>
<body>

                <div class="body"></div>
                <div class="header" > <center>IITB Blockchain</center>
		</div>

                <div  class="bar" width="100%">
                        <table table-layout="fixed" class="tblh" border="5">
                                                <tr>
                                                <th width="5%"> S NO.</th>
                                                <th width="25%"> Name of merchant</th>
                                                <th width="25%">  BTC Address</th>
                                                <th width="7%"> In </th>
                                                <th width="7%"> dIn </th>
                                                <th width="7%"> Out </th>
                                                <th width="7%"> dOut </th>
                                                <th width="7%">Balance</th>
                                                </tr>
                        </table>
                </div>

          <div class="content"> <br><br><br><br><br>
                        <table table-layout="fixed" class="tbl" border="2">';
           while($row = mysqli_fetch_array($response)){
               		                        echo' <tr>
                                                <td width="5%" >'.$row['Sno'].'</td>
                                                <td width="25%" > <a href="'.$row['Url'].'"style="text-decoration:none">
								<div style="height:100%;width:100%">'
      								.$row['Name'].'</div></a></td>
                                                <td width="25%" align="justify"> <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$row['Addr'].'" style="text-decoration:none">
								<div style="height:100%;width:100%">'
      								.$row['Addr'].'</div></a></td>
                                                <td width="7%" >'.$row['Inward']. '</td>
                                                <td width="7%" >'.$row['dInward']. '</td>
                                                <td width="7%" >'.$row['Outward']. '</td>
                                                <td width="7%" >'.$row['dOutward'].'</td>
                                                <td width="7%" >'.$row['Bal'].'</td>';
                                                echo'</tr>';
						}
                       echo' </table>
                               
                </div>
</body>
</html>';
} else {

echo "Couldn't issue database query<br />";

echo mysqli_error($dbc);

}

// Close connection to the database
mysqli_close($dbc);

?>
