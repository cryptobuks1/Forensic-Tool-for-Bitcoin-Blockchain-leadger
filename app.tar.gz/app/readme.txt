					@@@@@@   /var/www/html/app/readme.txt

		#### Script and files
1. index.html ----> Main file that contain the display of table.
2. 1.4.7L.txt ----> contain uniqe name+ url till block 470000
3. refresh.py ----> This script fetches all new address beyond a perticular input blockno.
4. style.css  ----> This file contains CSS for index.php and addhistory.php
5. addrhistory.php ----> This file displays the graph of the selected address
6. insert.php ----> This file inserts all the address + name + url from1.4.7L.txt to database details
7. fetchfromaddr.py--> This script fetches Balance, Inward and outward transactions.
8. refresh.php ---> This script find out the stored block height and the latest block height and calculates all the url and name present form a python
			file. Later it merge those new urls+names in details table. Later another python script updates the balance, inward...... 
9. balforaddress.py -> This script returns the balance of a perticular bitcoin addresss
10. addrforgraph.py -> retuen inward and outward address with balabce for a given address.
11. index1.php --> backup file for index.php
12. graph1.php --> backupfile for addrhistory.php
13. graph.php --> backup file for graph1.php
14. st.css --> New CSS file (used)
15. Add_addr.py --> this script return address+name+url for 1000 blocks only. Initial value is taken from tabe; Add_addr
16. Add_addr.php --> This page give the button Add Address on index.php
17. refresh_page.php --> (button on index.php)Just refresh all the exixtoing adress in the database
18. refresh_page.py --> return refreshed value for stored addres.


		#### Database Information ####
1. Database nmae ---> Bitcoin
2. Daabase UserId --> root
3. Databse Pasword--> pass
4. Table (details) --> This is main table that contains All the details
5. Table (refreshhistory)--> This contains information about when refresh button was invoked. Also contained the most recent updated block no
6. Table (Add_addr) --> Stored address till where name+url is added to mail database.   


		#### Resetting system.
1. delete all data from details databse
2. run insert.php, This will automatically take input from 1-4.3L.txt file and fill the details table
3. Reset the Auto_increment variable Sno=1302. 
4. run sql trim command on Address field as end character of every address has '\n' character.
6. delete all entries of rehresh_history table except the first one
7. run refresh.php file 
