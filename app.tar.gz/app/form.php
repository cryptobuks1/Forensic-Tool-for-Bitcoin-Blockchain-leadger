<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<body>

<div class="header" > <center>IITB Blockchain</center>

<form action="index.php" id="#form" method="post" name="#form">
<input id='btn' name="submit" type='submit' value='Submit'>';
<?php
echo "hi";
include "include/index.php"
?>
</form>

                </div>

                <div  class="bar" width="100%">
                        <table table-layout="fixed" class="tblh" border="5">
                                                <tr>
                                                <th width="5%"> S NO.</th>
                                                <th width="25%"> Name of merchant</th>
                                                <th width="25%">  BTC Address</th>
                                                <th width="7%"> In </th>
                                                <th width="7%"> dIn </th>
                                                <th width="7%"> Out </th>
                                                <th width="7%"> dOut </th>
                                                <th width="7%">Balance</th>
                                                </tr>
                        </table>
                </div>

          <div class="content"> <br><br><br><br><br>
                        <table table-layout="fixed" class="tbl" border="2">

<?php
 while($row = mysqli_fetch_array($response)){
                                                echo' <tr>
                                                <td width="5%" >'.$row['Sno'].'</td>
                                                <td width="25%" > <a href="'.$row['Url'].'"style="text-decoration:none">
                                                                <div style="height:100%;width:100%">'
                                                                .$row['Name'].'</div></a></td>
                                                <td width="25%" align="justify"> <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$row['Addr'].'" st$
                                                                <div style="height:100%;width:100%">'
                                                                .$row['Addr'].'</div></a></td>
                                                <td width="7%" >'.$row['Inward']. '</td>
                                                <td width="7%" >'.$row['dInward']. '</td>
                                                <td width="7%" >'.$row['Outward']. '</td>
                                                <td width="7%" >'.$row['dOutward'].'</td>
                                                <td width="7%" >'.$row['Bal'].'</td>';
                                                echo'</tr>';
                                                }

?>

 </table>

                </div>
</body>
</html>
<?php
} else {

echo "Couldn't issue database query<br />";

echo mysqli_error($dbc);

}

// Close connection to the database
mysqli_close($dbc);

?>
