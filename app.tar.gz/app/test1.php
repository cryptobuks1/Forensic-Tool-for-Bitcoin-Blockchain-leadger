<?php

$addr ="1CdJi2xRTXJF6CEJqNHYyQDNEcM3X7fUhD";
$return_var = "";

//$Var = system("sudo -u www-data python /var/www/html/app/addrforgraph.py ".$addr,$return_var);
//$Var = exec('/usr/bin/python2.7 /var/www/html/app/addrforgraph.py 1CdJi2xRTXJF6CEJqNHYyQDNEcM3X7fUhD');
ob_start();
passthru('/usr/bin/python2.7 /var/www/html/app/addrforgraph.py '.$addr);
$Var = ob_get_clean(); 

echo $Var;

?>
