<?php

echo '<html>
 <form action="/test.php" method="get">
  First name: <input type="text" name="fname"><br>
  Last name: <input type="text" name="lname"><br>
  <button type="submit" value="Submit">Submit</button>
</form>
	<body> Hiii</body>
   </html>	

?>
