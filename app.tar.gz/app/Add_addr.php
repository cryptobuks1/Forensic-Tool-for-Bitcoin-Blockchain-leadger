<?php
 
// Get a connection for the database
require_once('../mysqli_connect.php');

$Date = 0;
$Block = 0;        // Satoshi Block/ Parent Block
$record = 0;
$cnt = 0;    // count no. of new record added

// finding the latest block
// Create a query for the database// finding latest line in mysql
$query = "SELECT * FROM Add_addr ORDER BY Block_no DESC LIMIT 1";
$response = @mysqli_query($dbc, $query);
// If the query executed properly proceed


if($response){
		while($row = $response->fetch_assoc())
		{
			$Block = $row["Block_no"];
		}//while 
	//	echo "Block No:::",$Block,"\n";
	    }//if
       else {
		echo "Couldn't issue database query";
		echo mysqli_error($dbc);
	    }//else


echo "before";
//Runnnig script to fetch data using API API 
$var = system("sudo -u www-data python /var/www/html/app/Add_addr.py ".$Block);


$bigarray = explode("+",$var);


echo ' <title>		</title>
	<body>  <a  class="Link" href="http://bitcoin.isrdc.iitb.ac.in/app/index.php" > <h1> Back to index.php </h1></a>'; 

echo $var;


foreach ($bigarray as $key)
 { 
    echo gettype($key);
    $smallarray =explode("*", $key);
    $name = $smallarray[0];
    $url  = $smallarray[1]; 
    $addr = $smallarray[2];
//	echo "\r\n","\r\n";
    if(strlen($addr)>=25 and strlen($addr)<=36)
    	{	echo "\r\n","New","\r\n",	

		$query = "SELECT `Addr` FROM `details` where Addr='$addr'";
		$response = mysqli_query($dbc, $query);
		if(mysqli_num_rows($response)>0){
	//					echo "--if--";
        				while($row = $response->fetch_assoc())
        					{
               		 				$Addr = $row["Addr"];
							echo $Addr,"[][][][][[]Matched","\r\n";
					
		        			}//while
        		    }//if
		       else {
      	//	  	         echo "else)))))))))))))))****************************************************************************************";
				 $a = 0;
 				 $query = "INSERT INTO details (Name, Url,Addr, Inward, dInward, Outward, dOutward,Bal) VALUES (?,?, ?, ?,?, ?, ?, ?)";
				 $stmt = mysqli_prepare($dbc, $query);
				 mysqli_stmt_bind_param($stmt, "ssssssss",$name, $url,$addr,$a, $a, $a,$a,$a);
				 mysqli_stmt_execute($stmt);
				 echo "--------------------Notmatched-Inserted";
				 $cnt = $cnt + 1;
                            }//else
		
		
        }//if 

}//loop


//////////////////////////////////////////////------------------> update refresh_histry table in mysql
$smallarray = explode("+",$bigarray[0]);
$block = (int)$smallarray[0];

$servername = "localhost";
$username = "root";
$password = "pass";
$dbname = "Bitcoin";

$time = date('Y-m-d H:i:s');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Add_addr (Block_no)VALUES ('$block');";

if ($conn->multi_query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

echo ' <div> <h1> '.$cnt. ' New records added to database </h1> </body>';
$conn->close()



?>

