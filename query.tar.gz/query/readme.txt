				@@@ /var/www/html/query/readme.txt
		### files and scripts  
1. addrforgraph.py  ---> this script upon given a block no. outputs all address conatined in it.
2. st.css     ----> css file for front end
3. filter.php ---> this page contains interface to all filters that someone can apply.
4. displayfiletr1.php --> This page shows the output corresponding to filter1
5. displayfiletr2.php --> This page shows the output corresponding to filter2











		###  Dtabase and table
1. Database --> Bitcoin
2. table --> (Add_addr) contains Blockno. till where the script has fetched the address.

