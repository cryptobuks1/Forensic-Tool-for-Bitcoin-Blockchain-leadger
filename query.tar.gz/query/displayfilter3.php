<?php
// Get a connection for the database

require_once('../mysqli_connect.php');

$minblock = $_GET['minblock'];
$maxblock = $_GET['maxblock'];

$minval = $_GET['minval'];
$maxval = $_GET['maxval'];

$count =0;

ob_start();
passthru('/usr/bin/python2.7 /var/www/html/query/Blockvalidator.py '.$maxblock);
$Var1 = ob_get_clean();

// If the query executed properly proceed

if( $Var1==1 && $minblock>=0 && $maxblock >$minblock && $mival>=0 && $maxval>=$minval && $minval!='' && $maxval!='' && $minblock!='' && $maxblock!='')
{  
echo
'<html>
<head>
        <title> </title>
         <link rel="stylesheet" href="st.css">

</head>
<body>


                <div  class="bar" width="100%"> &emsp; &emsp; <abbr title="Go back to filter page">  <form action="http://bitcoin.isrdc.iitb.ac.in/query/filter.php?addr='.$addr.'">   <input type="submit" value="Query Page"> </form> </abbr> 

                        <table class="headtable">
                                                <tr>
                                                <th width="38%"> Senders Addr</th>
			                         <th width="38%"> Receivers Addr</th>
                                                <th width="12%"> Amount </th>
                                                <th width="8%"> Block No </th>
                                                <th width="4%"> Link </th>
                                                </tr>
                        </table>
                </div>
		<br><br><br><br><br><br><br>

          <div class="graph"> ';
				for($i=$minblock;$i<$maxblock;$i++)
				{	
					 $addr = (string)$i;
					 ob_start();
		                         passthru('/usr/bin/python2.7 /var/www/html/query/filter3.py '.$addr);
                		         $Var = ob_get_clean();
					 //echo $Var;	

					 $Var = explode("@",$Var);
					
					 for($j=0;$j<count($Var);$j++)
					  {
						// break the String
						 $Str = explode("*",$Var[$j]);
						 $Block = $Str[0];
						 $Hash = $Str[1];
						 $left = explode("+",$Str[2]);
						 $right = explode("+",$Str[3]);

						 $flag = 1;
/*
						for($k=0;$k<count($max);$k++)
                                                        {
                                                                $R = explode("%",$right[$k]);
                                                                  echo "{( ",$R[0]," ",$R[1]," )}";

                                                        }
*/
						 // check for filter constraint for right
						$d = 0; //echo "count=",count($right);
						 for($k=0;$k<count($right);$k++)
                                                  { 
                                                    $temp = explode("%",$right[$k]);
					            //echo "{Temp( ",$temp[0]," ",$temp[1]," )}";
						    $b = floatval($temp[1])*10**(-8);
                                                    if($temp[1] >= $minval*10**(8) && $temp[1] <= $maxval*10**(8))
                                                        {$d++; }
						   /* else {  $flag = 0; echo "{( else ",$temp[0]," ",$temp[1]," Seleceted)}";;  break;} */
                                                  }//check for left
					/*
						for($k=0;$k<count($max);$k++)
                                                        {
                                                                $R = explode("%",$right[$k]);
                                                                  echo "{( ",$R[0]," ",$R[1]," )}";

                                                        }
					*/
					
						 if($d == count($right))// values are correct
						  {
/*							for($k=0;$k<count($right);$k++)
                                                        {
                                                                $R = explode("%",$right[$k]);
                                                                  echo "{( ",$R[0]," ",$R[1]," )}";

                                                        }

*/
							$flag1 = 0;
						      // Equalize both left and right array
						         if(count($left) <= count($right))
						            { $max = count($right); $flag1 = 1;}
						         else $max = count($left);

						        if($flag1==0)	
						        {  for($k=count($left);$k<$max;$k++)
								$left[$k]=" ";
						        }	
							else{
 							 for($k=count($right);$k<$max;$k++)
                                                                $right[$k]=" ";
							   }
							// Sending values to output
							
		/*					for($k=0;$k<count($max);$k++)
							{
								$R = explode("%",$right[$k]);
								  echo "{( ",$R[0]," ",$R[1]," )}";								
	
							}							

		*/
						    echo'
							<table width="100%">';							
							for($k=0;$k<$max;$k++)
							 {
							   $R = explode("%",$right[$k]);
							  
	                                                 $b = floatval($R[1])*10**(-8);
        	                                         $Bal = number_format((float)$b, 8, '.', '');
							   
						//	 echo "{",$R[1]," ",$b," ",$Bal,"}";
							 $query = "select `Name`,`Url` from `details` where Addr='$left[$k]'";
			                                 $resultl = mysqli_query($dbc,$query);
						
							 $query = "select `Name`,`Url` from `details` where Addr='$R[0]'";
			                                 $resultr = mysqli_query($dbc,$query);


							 echo'<tr>';
							 if(mysqli_num_rows($resultl)>0)
							 {
								$row = $resultl->fetch_assoc();
                                                       		$Name = $row["Name"];
                                                        	$Url = $row["Url"];
							 	echo' <td width="38%"  bgcolor="#00ff00" > <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$left[$k].'" style="text-decoration:none"> '.$Name.'</td>';
							 }
							else{
							 	echo' <td width="38%"> '.$left[$k].'</td>';
							    }
							
							if(mysqli_num_rows($resultr)>0)
							{
							 $row = $resultr->fetch_assoc();
                                                                $Name = $row["Name"];
                                                                $Url = $row["Url"];
							  echo '<td width="38%" bgcolor="#00ff00"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$R[0].'" style="text-decoration:none"> '.$Name.'</td>';
							}
							else 
							{
							echo ' <td width="38%"> '.$R[0].'</td>';
							}

							
							echo'<td width="12%" align="right"> '.$Bal.' </td>
							  <td width="8%" align="right"> '.$Block.' </td>
							  <td width="4%">  <center> <a href="https://blockchain.info/tx/'.$Hash.'"> <img border="0" alt="W3Schools" src="Arrow.png"width="30" height="30"></a> </center> </td>
							       </tr>';						   
							 }
							echo' </table> <br><br>';
							$count ++; // No. of trnasactions
						  }// final printable values						

					  }//innner for loop 

				}//for main loop	

	  echo'   
                               
        </div>

	 </div>
        <div class="footer"> <center> Page Summary with filter <br> >= '.$minval.' BTC &&  <='.$maxval.' BTC </center> <br>
                                 <table> <tr>   <th> From Block('.$minblock.') ::  #Transactions ('.$count.') ::  Till Block('.$maxblock.')</th> </tr>
                                </table>
        <br>
        </div>

</body>
</html>';
}
else { echo "Please check your Input Or check internet connection at server side";}
// Close connection to the database
mysqli_close($dbc);

?>
