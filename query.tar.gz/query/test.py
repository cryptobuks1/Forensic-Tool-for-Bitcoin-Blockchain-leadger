import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0
addr = ""


minblock = 1000;
maxblock = 1010;

minval = 0.3;
maxval = 0.4;

url = "https://blockchain.info/block-height/300000?format=json"
response = urllib.urlopen(url)
data = json.loads(response.read())

#for i in range(0,2):
 #  for j in range(0,1):	
#print data['blocks'][0]['tx']

print sys.argv[1],sys.argv[2]
