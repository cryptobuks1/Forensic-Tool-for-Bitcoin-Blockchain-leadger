<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

$addr = $_GET['addr'];

// If the query executed properly proceed

echo
'<html>
<head>
        <title> </title>
         <link rel="stylesheet" href="st.css">

</head>
<body>

             <div  class="bar" width="100%">  <p class="add">  &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;    &emsp;&emsp;   &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;    &emsp;&emsp; &emsp;&nbsp; &emsp;&emsp;  &emsp; &emsp; &emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; <abbr title="This page contains diffrenet filters that can be applied to BTC address "> Filter Page  </abbr>   &emsp;  &emsp;&emsp; &emsp; &emsp; &emsp;&emsp;  &emsp;&emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; &emsp;  </p>
							
                </div>
		<br><br><br><br><br>
               <br><br>
		<div class="filter" width="100%">  #Filter1 <br> ** Enter a key address and range of Bitcoin value. <br> ** Output :: All those address which have done transaction of BTC in provided range with key address. <br>  &emsp;
								<form action="http://bitcoin.isrdc.iitb.ac.in/query/displayfilter1.php">
  								<input  size="16"  type="text" name="minval" placeholder="Minimum #BTC"> 
								 &emsp;
								<input size="36" type="text" name="addr" value="'.$addr.'" placeholder="BTC Address">
                                                                &emsp;
                                                                <input  size="16"  type="text" name="maxval" placeholder="Maximum #BTC"> <br> <br>
  								&emsp; &emsp;
  								<input type="submit" value="Find">
								</form> 
		 <div>		
				<br><br>
		 <div class="filter" width="100%">  #Filter2 <br> ** Enter the range of BTC value. <br> ** Output will be set of address (stored in local database) which have balalnce in given BTC range.   <br>  &emsp;
                                                                <form action="http://bitcoin.isrdc.iitb.ac.in/query/displayfilter2.php">
                                                                <input  size="16"  type="text" name="minval" placeholder="Minimum #BTC">
                                                                 &emsp;
                                                                <input  size="16"  type="text" name="maxval" placeholder="Maximum #BTC"> <br> <br>
                                                                &emsp; &emsp;
                                                                <input type="submit" value="Find">
                                                                </form>
                 <div>


		<br><br>
                <div class="filter" width="100%">  #Filter3 <br> ** Enter the range of Block number & the range of #BTC<br> ** Output :: All those pair of BTC address which have done the transaction in between given range of blocks with #BTC constrained </br>
                                                                <form action="http://bitcoin.isrdc.iitb.ac.in/query/displayfilter3.php">
                                                                <input  size="16"  type="text" name="minblock" placeholder="Minimum Block No"> 
								&emsp;	
								<input  size="16"  type="text" name="maxblock" placeholder="Maximum Block No"> 
                                                                &emsp;
                                                                <input  size="16"  type="text" name="minval" placeholder="Minimum #BTC"> 
                                                                &emsp;
                                                                <input  size="16"  type="text" name="maxval" placeholder="Maximum #BTC"> <br> <br>
                                                                &emsp; &emsp;
                                                                <input type="submit" value="Find">
                                                                </form> 
                 <div>          

</body>
</html>';

// Close connection to the database
mysqli_close($dbc);

?>
