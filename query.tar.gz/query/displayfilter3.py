# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 12:11:37 2017

@author: syed
"""
from smtplib import SMTP as SMTP 

# Given a blockno this Script can fetch all address in rest of the blocks;

import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0
addr = ""



def Fetch(val):
        i  = 0
        j = 0
  	k = 0
    	Block= str(val)
    	url = "https://blockchain.info/block-height/"+Block+"?format=json"
    	response = urllib.urlopen(url)
    	data = json.loads(response.read())
	Str  = ''
    	for i in range(0,len(data['blocks'][0]['tx'])):
		hash = data['blocks'][0]['tx'][i]['hash']
		Str0 = str(Block) + "*" + str(hash)+"*"
		Str1 = ''

		for j in range(0,len(data['blocks'][0]['tx'][i]['inputs'])):
				
			if(data['blocks'][0]['tx'][i]['inputs'][j].has_key("prev_out")):
				Str1 = Str1 +  str(data['blocks'][0]['tx'][i]['inputs'][j]["prev_out"]['addr'])# +"%"+ str(data['blocks'][0]['tx'][i]['inputs'][j]["prev_out"]['value'])
			else:
				Str1 = Str1 + "Newly_generated_coin" + "%" + "XXX"
			if(j < len(data['blocks'][0]['tx'][i]['inputs']) - 1):
					Str1 = Str1 + "+"
		Str1 = Str1 + "*"
		Str2 = ''
	    	for j in range(0,len(data['blocks'][0]['tx'][i]['out'])):
			#if(data['blocks'][0]['tx'][i]['out'][j]['value'] >=minval*10**8 && data['blocks'][0]['tx'][i]['out'][j]['value'] <=maxval*10**8):
    				Str2 = Str2 + str(data['blocks'][0]['tx'][i]['out'][j]['addr'])+"%"+ str(data['blocks'][0]['tx'][i]['out'][j]['value'])
				if(j < len(data['blocks'][0]['tx'][i]['out'])-1):
					Str2 = Str2 + "+"
		Str = Str + Str0 + Str1 + Str2
		
		if(i < len(data['blocks'][0]['tx'])-1):
			  Str = Str + "@"
	#print data['blocks'][0]['tx'][1] 
	print Str
	f = open("block.txt","w")
	f.write(Str)
	f.close()
	return Str

addr=sys.argv[1]
minval = sys.argv[2]
maxval = sys.argv[3]
Fetch(addr,minval,maxval)



