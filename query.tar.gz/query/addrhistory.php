<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

$addr =  $_GET['addr'];
$in = $_GET['in'];
$out = $_GET['out'];


//$in = 0;
//$out = 0;

// If the query executed properly proceed

echo
'<html>
<head>
        <title> </title>
         <link rel="stylesheet" href="st.css">

</head>
<body>


                <div  class="bar" width="100%"> &emsp; &emsp; <abbr title="Go back to filter page">  <form action="http://bitcoin.isrdc.iitb.ac.in/query/filter.php?addr='.$addr.'">   <input style="float:right; type="submit" value="Query Page"> </form> </abbr> 
		<p class="add">  &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; <abbr title="Address which have paid to key addr">  #Inward_Transactions('.$in.') </abbr>    &emsp;&emsp; &emsp;&nbsp; &emsp;&emsp;  &emsp; &emsp; &emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; <abbr title="Key Addr"> '.$addr.' </abbr>   &emsp;  &emsp; &emsp;&emsp;  &emsp;&emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; &emsp; <abbr title="Address which have recieved bitcoin from key addr"> #Outward_Transactions('.$out.')  </abbr> </p>  <br><br><br><br>

                        <table class="headtable">
                                                <tr>
                                                <th width="290"> Incoming Address</th>
                                                <th width="125"> Amount</th>
                                                <th width="220"> Key Address</th>
                                                <th width="125"> Amount </th>
                                                <th width="290"> Outward Adddress </th>
                                                </tr>
                        </table>
                </div>
		<br><br><br><br><br><br><br>

          <div class="graph"> 

		<table class="maintable">




		     <td class="td2">  <table  width="400" bgcolor="#33ccff"  font-family="monospace" float="left"><br><br><br> ';
			ob_start();
			passthru('/usr/bin/python2.7 /var/www/html/app/addrforgraph.py '.$addr);
			$Var = ob_get_clean();

			$Array = explode("*",$Var);
			$Inward = explode("+",$Array[0]);
		        $Outward = explode("+",$Array[1]);
			$Inlength = count($Inward);
			$Outlength = count($Outward);
			$x = 0;
		    for($x =1;$x<$Inlength;$x++)
			{	
				$Ad = explode(":",$Inward[$x]);

						 $b = floatval($Ad[1])*10**(-8);
                                                 $Bal = number_format((float)$b, 8, '.', '');


				$query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
				$result = mysqli_query($dbc,$query);
				 if(mysqli_num_rows($result)>0)
				 {
							$row = $result->fetch_assoc();                                                
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];

  					     echo'   <tr><td class="td3" width="250" align="justify" bgcolor="#00ff00"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"> '.$Name.'</td>
                                             <td class="td3" align="right" width="150">'.$Bal.'</td>
                                             </tr>';
                                 }//if
				 else{	
              				echo'	<tr> 
				 	<td width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none">'.$Ad[0].'</td>
                			 <td width="150" align="right">'.$Bal.'</td>
           		       			</tr>';
				   }//else
		       }// Inward for looop
		       echo'   </table>
     		     </td>';


	echo'
		   <td class="td2">	
		  <table width="250" font-family="monospace" bgcolor="#33ccff" float="left">';
		
		      $query = "select `Name`,`Url` from `details` where Addr='$addr'";
                                $result = mysqli_query($dbc,$query);
                         
		        if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                             echo'  <tr><td class="td3" width="250" align="justify" bgcolor="#00ff00"> <a href="'.$Url.'" style="text-decoration:none"><center> '.$Name.'  </center></td>
                                                   </tr>';
                                 }//if
                                 else{
                                        echo'   <tr >
	                  			  <td width="250"><center> '.$addr.'</center></td>
		                               </tr>';
                                   }//else
		echo'  </table>
                    </td>';






	      	echo'		<td class="td2">  <table  width="400" bgcolor="#33ccff" float="left"> ';
			$x = 0;
		   for($x=1;$x<$Outlength;$x++)
			{       
				 $Ad = explode(":",$Outward[$x]);
					
					$b = floatval($Ad[1])*10**(-8);
                                        $Bal = number_format((float)$b, 8, '.', '');


				 $query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
                                 $result = mysqli_query($dbc,$query);
                                 if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                        echo' <tr>
                			   <td class="td3" width="150" align="right">'.$Bal.'</td>  
					   <td class="td3" width="250" align="justify"  bgcolor="#00ff00"> <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none">'.$Name.'</td>
                                             </tr>';
                                 }//if
                                 else{
             				echo'	 <tr>
                			   <td align="right" width="150">'.$Bal.'</td> 
                			   <td><width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"> '.$Ad[0].'</td>
              			  		</tr>';
				    }//else
			}//oUtward for loop  
          		echo'	 </table>

      			</td>';  
       echo'    </table>
                               
        </div>
</body>
</html>';

// Close connection to the database
mysqli_close($dbc);

?>
