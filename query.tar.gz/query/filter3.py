# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 12:11:37 2017

@author: syed
"""
from smtplib import SMTP as SMTP 

# Given a blockno this Script can fetch all address in rest of the blocks;

import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 0
addr = ""
block = str(sys.argv[1])
#block = "400000"



url = "https://blockchain.info/block-height/"+block+"?format=json"
response = urllib.urlopen(url)
data = json.loads(response.read())

def fetch(block):
    Str = ""
    for i in range(0,len(data['blocks'][0]['tx'])):
    	Str1  = ''
    	Str2  = ''
    	Str = Str + block + "*" +  str(data['blocks'][0]['tx'][i]['hash']) + "*"	
    	for j in range(0,len(data['blocks'][0]['tx'][i]['inputs'])):
    		if(data['blocks'][0]['tx'][i]['inputs'][j].has_key('prev_out')):
			Str1 = Str1 + str(data['blocks'][0]['tx'][i]['inputs'][j]['prev_out']['addr'])
			if(j< len(data['blocks'][0]['tx'][i]['inputs'])-1):
				Str1 = Str1 + "+"
    		else:
			Str1 = Str1 + "Newly_Genarated_Coin"
    	Str1 = Str1 + "*"	  	

    	for j in range(0,len(data['blocks'][0]['tx'][i]['out'])):	
		if(data['blocks'][0]['tx'][i]['out'][j].has_key('addr')):
			Str2 = Str2 + str(data['blocks'][0]['tx'][i]['out'][j]['addr']) + "%"+ str(data['blocks'][0]['tx'][i]['out'][j]['value'])

		if(j < len(data['blocks'][0]['tx'][i]['out'])-1):
			Str2 = Str2 + "+"
    	Str = Str + Str1 + Str2
    	if(i< len(data['blocks'][0]['tx'])-1):
		Str = Str + "@"
    print Str
    f = open("block.txt","w")
    f.write(Str)
    f.close()
    return Str


block = sys.argv[1]
fetch(block)
