# -*- coding: utf-8 -*-

import urllib, json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
i = 5

# find address-> url+names just by block number
### Will generate a file containg bnameas and url of the address


def Fetch(addr):
    url = "https://blockchain.info/rawaddr/"+addr
    try:	
         response = urllib.urlopen(url)
   	 data = json.loads(response.read())
   	 i = 1
    except:
	 i = 0
    return i	 


def Return():
	addr = sys.argv[1]
	k = Fetch(addr)
	print k
	return k

Return()
