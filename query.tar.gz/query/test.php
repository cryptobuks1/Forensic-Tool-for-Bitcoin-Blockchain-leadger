<?php


	$addr=400000;
	$addr = (string)$addr;
    				 ob_start();
                                 passthru('/usr/bin/python2.7 /var/www/html/query/filter3.py '.$addr);
                                 $Var = ob_get_clean();

print $Var

?>
