<?php
// Get a connection for the database
require_once('../mysqli_connect.php');

$addr =  $_GET['addr'];
$in = 0;
$out = 0;
$inbal = 0;
$outbal= 0;

$minval = $_GET['minval'];
$maxval = $_GET['maxval'];

ob_start();
passthru('/usr/bin/python2.7 /var/www/html/query/Addressvalidator.py '.$addr);
$Var1 = ob_get_clean();

//$in = 0;
//$out = 0;

// If the query executed properly proceed

if($Var1==1 && $minval>=0 && $maxval>=$minval)
{
echo
'<html>
<head>
        <title> </title>
         <link rel="stylesheet" href="st.css">

</head>
<body>


                <div  class="bar" width="100%"> &emsp; &emsp; <abbr title="Go back to filter page">  <form action="http://bitcoin.isrdc.iitb.ac.in/query/filter.php?addr='.$addr.'">   <input type="submit" value="Query Page"> </form> </abbr> 
	<!--	<p class="add">  &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; <abbr title="Address which have paid to key addr">  #Inward_Transactions('.$in.') </abbr>    &emsp;&emsp; &emsp;&nbsp; &emsp;&emsp;  &emsp; &emsp; &emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; <abbr title="Key Addr"> '.$addr.' </abbr>   &emsp;  &emsp; &emsp;&emsp;  &emsp;&emsp; &emsp;  &emsp; &emsp; &emsp; &emsp; &emsp; <abbr title="Address which have recieved bitcoin from key addr"> #Outward_Transactions('.$out.')  </abbr> </p> -->  <br><br><br><br>

                        <table class="headtable">
                                                <tr>
                                                <th width="290"> Incoming Address</th>
                                                <th width="125"> Amount</th>
                                                <th width="220"> Key Address</th>
                                                <th width="125"> Amount </th>
                                                <th width="290"> Outward Adddress </th>
                                                </tr>
                        </table>
                </div>
		<br><br><br><br><br><br><br>

          <div class="graph"> 

		<table class="maintable">




		     <td class="td2">  <table  width="400" bgcolor="#33ccff"  font-family="monospace" float="left"><br><br><br> ';
			ob_start();
			passthru('/usr/bin/python2.7 /var/www/html/app/addrforgraph.py '.$addr);
			$Var = ob_get_clean();

			$Array = explode("*",$Var);
			$Inward = explode("+",$Array[0]);
		        $Outward = explode("+",$Array[1]);
			$Inlength = count($Inward);
			$Outlength = count($Outward);
			$x = 0;
		    for($x =1;$x<$Inlength;$x++)
			{	
				$Ad = explode(":",$Inward[$x]);

						 $b = floatval($Ad[1])*10**(-8);
                                                 $Bal = number_format((float)$b, 8, '.', '');
									
		if($Bal>=$minval && $Bal<=$maxval)
			{
				$inbal = $inbal + $Bal;
				$in = $in + 1;
		 if($addr != $Ad[0])
                	    { // Key adress stopper 
				$query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
				$result = mysqli_query($dbc,$query);
				 if(mysqli_num_rows($result)>0)
				 {
							$row = $result->fetch_assoc();                                                
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];

  					     echo'   <tr><td class="td3" width="250" align="justify" bgcolor="#00ff00"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"> '.$Name.'</td>
                                             <td class="td3" align="right" width="150">'.$Bal.'</td>
					    <td class="td3"  width="10"> <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0"
						alt="W3Schools"src="arrow.png" width="10" height="10"></a> </td>

                                             </tr>';
                                 }//if
				 else{	
              				echo'	<tr> 
				 	<td width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none">'.$Ad[0].'</td>
                			 <td width="150" align="right">'.$Bal.'</td>
 					<td  width="10"> <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0" alt="W3Schools"src="arrow.png" width="10" height="10"></a> </td>
           		       			</tr>';
				   }//else
			   }// key address stopper
		    }//filter if Balance
		       }// Inward for looop
		       echo'   </table>
     		     </td>';


	echo'
		   <td class="td2">	
		  <table width="250" font-family="monospace" bgcolor="#33ccff" float="left">';
		
		      $query = "select `Name`,`Url` from `details` where Addr='$addr'";
                                $result = mysqli_query($dbc,$query);
                         
		        if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                             echo'  <tr><td class="td3" width="250" align="justify" bgcolor="#00ff00"> <a href="'.$Url.'" style="text-decoration:none"><center> '.$Name.'  </center></td>
                                                   </tr>';
                                 }//if
                                 else{
                                        echo'   <tr >
	                  			  <td width="250"><center> '.$addr.'</center></td>
		                               </tr>';
                                   }//else
		echo'  </table>
                    </td>';






	      	echo'		<td class="td2">  <table  width="400" bgcolor="#33ccff" float="left"> ';
			$x = 0;
		   for($x=1;$x<$Outlength;$x++)
			{       
				 $Ad = explode(":",$Outward[$x]);
					
					$b = floatval($Ad[1])*10**(-8);
                                        $Bal = number_format((float)$b, 8, '.', '');
	          if($Bal>=$minval && $Bal<=$maxval)
		    {
			$out = $out + 1;
			$outbal = $outbal + $Bal;
		    if($addr != $Ad[0])
                     { // key address stopper

				 $query = "select `Name`,`Url` from `details` where Addr='$Ad[0]'";
                                 $result = mysqli_query($dbc,$query);
                                 if(mysqli_num_rows($result)>0)
                                 {
                                                        $row = $result->fetch_assoc();
                                                        $Name = $row["Name"];
                                                        $Url = $row["Url"];
                                        echo' <tr>
					   <td class="td3"  width="10"> <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0" alt="W3Schools"src="arrow.png" width="10" height="10"></a> </td>
                			   <td class="td3" width="150" align="right">'.$Bal.'</td>  
					   <td class="td3" width="250" align="justify"  bgcolor="#00ff00"> <a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none">'.$Name.'</td>
                                             </tr>';
                                 }//if
                                 else{
             				echo'	 <tr>
 					   <td width="10"> <a href="https://blockchain.info/tx/'.$Ad[2].'"> <img border="0" alt="W3Schools"src="arrow.png" width="10" height="10"></a> </td>
                			   <td align="right" width="150">'.$Bal.'</td> 
                			   <td><width="250" align="justify"><a href="http://bitcoin.isrdc.iitb.ac.in/app/addrhistory.php?addr='.$Ad[0].'" style="text-decoration:none"> '.$Ad[0].'</td>
              			  		</tr>';
				    }//else
				}// key address stopper
			}//FILTER IF Balance
		  }//oUtward for loop  
          		echo'	 </table>

      			</td>';  
       echo'    </table>
                               
        </div>

	 </div>
        <div class="footer"> <center> Page Summary with filter <br> >= '.$minval.' BTC &&  <='.$maxval.' BTC </center> <br>
                                 <table> <tr>   <th align="left"> #Inward Nodes('.$in.')   Total # Received BTC('.$inbal.')</th> </tr>
                                         <tr>   <th> '.$addr.' </th> </tr>
                                         <tr>   <th align="right"> #Outward Nodes('.$out.')   Total # Received BTC('.$outbal.') </th> </tr>
                                </table>
        <br>
        </div>

</body>
</html>';
}
else { echo "Please check your Input Or check internet connection at server side";
if(Var1==0)
echo "   -->  Please Enter correct BTC Addr   <--"; }
// Close connection to the database
mysqli_close($dbc);

?>
